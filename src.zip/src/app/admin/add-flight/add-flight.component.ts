import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Post } from '../post';

@Component({
  selector: 'app-add-flight',
  templateUrl: './add-flight.component.html',
  styleUrls: ['./add-flight.component.css']
})
export class AddFlightComponent implements OnInit {

  form: FormGroup;

  constructor( public postService: PostService,
    private router: Router) {
   
   }

  ngOnInit(): void {
    this.form = new FormGroup({
      airlineName: new FormControl('', [Validators.required]),
      flightNumber: new FormControl('', Validators.required),
      contactNumber: new FormControl('', [Validators.required]),
      contactAddress: new FormControl('', Validators.required)
    });
  }
   
  get f(){
    return this.form.controls;
  }
    
  submit(){
    console.log(this.form.value);
    this.postService.create(this.form.value).subscribe(res => {
         console.log('Flight added successfully!');
         this.router.navigateByUrl('admin/index');
    })
  }

}
