export interface Post {
    id: number;
    airlineName: string;
    flightNumber: string;
    contactNumber: number;
    contactAddress: string;
}