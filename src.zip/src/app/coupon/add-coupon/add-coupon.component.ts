import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { CouponService } from '../coupon.service';

@Component({
  selector: 'app-add-coupon',
  templateUrl: './add-coupon.component.html',
  styleUrls: ['./add-coupon.component.css']
})
export class AddCouponComponent implements OnInit {


  
    form: FormGroup;
  
    constructor(  public couponService: CouponService,
      private router: Router) {
     
     }
  
    ngOnInit(): void {
      this.form = new FormGroup({
        couponCode: new FormControl('', [Validators.required]),
        coupenValue: new FormControl('', Validators.required)
      });
    }
     
    get f(){
      return this.form.controls;
    }
      
    submit(){
      console.log(this.form.value);
      this.couponService.create(this.form.value).subscribe(res => {
           console.log('Coupon added successfully!');
           this.router.navigateByUrl('coupon/index-coupon');
      })
    }
  
  }
  
