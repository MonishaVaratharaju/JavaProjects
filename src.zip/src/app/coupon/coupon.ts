export interface Coupon {
    id: number;
    couponCode: string;
    coupenValue: number;
}