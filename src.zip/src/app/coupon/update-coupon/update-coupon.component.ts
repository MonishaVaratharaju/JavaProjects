import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Coupon } from '../coupon';
import { CouponService } from '../coupon.service';

@Component({
  selector: 'app-update-coupon',
  templateUrl: './update-coupon.component.html',
  styleUrls: ['./update-coupon.component.css']
})
export class UpdateCouponComponent implements OnInit {
    
    id: number;
    coupon: Coupon;
    form: FormGroup;
    
    constructor(
      public couponService: CouponService,
      private route: ActivatedRoute,
      private router: Router
    ) { }
    
    ngOnInit(): void {
      this.id = this.route.snapshot.params['postId'];
      this.couponService.find(this.id).subscribe((data: Coupon)=>{
        this.coupon = data;
      });
      
      this.form = new FormGroup({
        couponCode: new FormControl('', [Validators.required]),
        coupenValue: new FormControl('', Validators.required)
        
      });
    }
     
    get f(){
      return this.form.controls;
    }
       
    submit(){
      console.log(this.form.value);
      this.couponService.update(this.id, this.form.value).subscribe(res => {
           console.log('Coupon updated successfully!');
           this.router.navigateByUrl('coupon/index-coupon');
      })
    }
     
  }
