import { Component, OnInit } from '@angular/core';
import { Coupon } from '../coupon';
import { CouponService } from '../coupon.service';


@Component({
  selector: 'app-index-coupon',
  templateUrl: './index-coupon.component.html',
  styleUrls: ['./index-coupon.component.css']
})
export class IndexCouponComponent implements OnInit {

  coupons: Coupon[] = [];
  
    constructor(public couponService: CouponService) { }
  
    ngOnInit(): void {
      this.couponService.getAll().subscribe((data: Coupon[])=>{
        this.coupons = data;
        console.log(this.coupons);
      })  
    }
    
    deleteCoupon(id: number){
      this.couponService.delete(id).subscribe(res => {
           this.coupons = this.coupons.filter(item => item.id !== id);
           console.log('Post deleted successfully!');
      })
    }
  
  }
  
