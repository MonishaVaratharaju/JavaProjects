import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
   
import {  Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Coupon } from './coupon';
  

@Injectable({
  providedIn: 'root'
})
export class CouponService {

  private apiURL = "http://localhost:3000";
   
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  

  constructor(private httpClient: HttpClient) { }

  getAll(): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>(this.apiURL + '/coupon/')
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  create(post: any): Observable<Coupon> {
    return this.httpClient.post<Coupon>(this.apiURL + '/coupon/', JSON.stringify(post), this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }  
   
  find(id: string | number): Observable<Coupon> {
    return this.httpClient.get<Coupon>(this.apiURL + '/coupon/' + id)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  update(id: string | number, post: any): Observable<Coupon> {
    return this.httpClient.put<Coupon>(this.apiURL + '/coupon/' + id, JSON.stringify(post), this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  delete(id: string | number){
    return this.httpClient.delete<Coupon>(this.apiURL + '/coupon/' + id, this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }
    
  
  errorHandler(error: { error: { message: string; }; status: any; message: any; }) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
 }
}
