import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookFlightComponent } from './book-flight/book-flight.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { IndexComponent } from './admin/index/index.component';
import { ViewComponent } from './admin/view/view.component';
import { UpdateComponent } from './admin/update/update.component';
import { AdminComponent } from './admin/admin.component';
import { AddFlightComponent } from './admin/add-flight/add-flight.component';
import { IndexCouponComponent } from './coupon/index-coupon/index-coupon.component';
import { UpdateCouponComponent } from './coupon/update-coupon/update-coupon.component';
import { AddCouponComponent } from './coupon/add-coupon/add-coupon.component';
import { IndexScheduleComponent } from './schedule/index-schedule/index-schedule.component';
import { UpdateScheduleComponent } from './schedule/update-schedule/update-schedule.component';
import { AddScheduleComponent } from './schedule/add-schedule/add-schedule.component';
import { TicketDetailsComponent } from './ticket-details/ticket-details.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [
  {path : '', component : LoginComponent},
  {path : 'home', component : HomeComponent},
  {path : 'booking', component : BookFlightComponent},
  { path: 'admin', component: AdminComponent },
  { path: 'admin/index', component: IndexComponent },
  { path: 'admin/:postId/view', component: ViewComponent },
  { path: 'admin/:postId/edit', component: UpdateComponent },
  { path: 'admin/add-flight', component: AddFlightComponent },
  { path: 'coupon/index-coupon', component: IndexCouponComponent },
  { path: 'coupon/:postId/update-coupon', component: UpdateCouponComponent },
  { path: 'coupon/add-coupon', component: AddCouponComponent },
  { path: 'schedule/:postId/edit', component: UpdateScheduleComponent },
  { path: 'schedule/index-schedule', component: IndexScheduleComponent },
  { path: 'schedule/add-schedule', component: AddScheduleComponent },
  { path: 'booking/ticket-details', component: TicketDetailsComponent },
  { path: 'registration', component: RegistrationComponent }
 
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
