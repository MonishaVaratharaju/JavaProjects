import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { BookFlightService } from '../book-flight.service';

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css']
})
export class BookFlightComponent implements OnInit {

 
    
      form: FormGroup;
      flag=false;
    
      constructor(  public bookFlightService: BookFlightService,
        private router: Router) {
       
       }
    
      ngOnInit(): void {
        this.form = new FormGroup({
          adults: new FormControl('', [Validators.required]),
          emailid: new FormControl('', Validators.required),
          mobilenumber: new FormControl('', [Validators.required]),
          coupon: new FormControl('', Validators.required)
        });
      }
       
      get f(){
        return this.form.controls;
      }
        
      submit(){
        console.log(this.form.value);
        this.bookFlightService.create(this.form.value).subscribe(res => {
             console.log('Flight booked successfully!');
             this.flag=true
            // this.router.navigateByUrl('booking/ticket-details');
        })
      }
    
    }
    
  
