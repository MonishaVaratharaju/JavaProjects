export interface BookFlight {
adults:number;
emailid:string;
mobilenumber:string;
coupon:string;

}
