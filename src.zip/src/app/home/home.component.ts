import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FlightService } from '../services/flight.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  booking = "oneway";
  exampleFlag = true;
  flights: any = [];
  edited = false;

  constructor(private flightService: FlightService, private router: Router) { }

  ngOnInit(): void {
  }

  changeBooking(e: any) {
    if (e.target.value == "roundtrip") {
      this.booking = "roundtrip";
      this.exampleFlag = false;
    }
    else {
      this.booking = "oneway";
      this.exampleFlag = true;
    }
  }

  searchFlights(form: NgForm): void {

    if (form.value.from == form.value.to) {
      alert('Choose different places');
    }
    else if (form.value.depature == '' || form.value.from == '' || form.value.to == '' || form.value.return == '') {
      this.edited = false;
      alert('Mandatory fields required!');
    }
    else {
      this.edited = true;
      this.flightService.searchFlight(form.value.from, form.value.to).subscribe((result) => {
        this.flights = result;
      }, (err) => {
        console.log(err);
      });
    }
  }

  bookflight() {
    console.log("Flight booked successfully");
    this.router.navigate(["booking"]).then(() => {
      window.location.reload();
    });
  }


}
