import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { BookFlightComponent } from './book-flight/book-flight.component';
import { AddFlightComponent } from './admin/add-flight/add-flight.component';
import { IndexComponent } from './admin/index/index.component';
import { ViewComponent } from './admin/view/view.component';
import { UpdateComponent } from './admin/update/update.component';
import { AdminComponent } from './admin/admin.component';
import { IndexCouponComponent } from './coupon/index-coupon/index-coupon.component';
import { AddCouponComponent } from './coupon/add-coupon/add-coupon.component';
import { UpdateCouponComponent } from './coupon/update-coupon/update-coupon.component';
import { IndexScheduleComponent } from './schedule/index-schedule/index-schedule.component';
import { UpdateScheduleComponent } from './schedule/update-schedule/update-schedule.component';
import { AddScheduleComponent } from './schedule/add-schedule/add-schedule.component';
import { TicketDetailsComponent } from './ticket-details/ticket-details.component';
import { RegistrationComponent } from './registration/registration.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    BookFlightComponent,
    IndexComponent,
    ViewComponent,
    UpdateComponent,
    AdminComponent,
    AddFlightComponent,
    IndexCouponComponent,
    AddCouponComponent,
    UpdateCouponComponent,
    IndexScheduleComponent,
    UpdateScheduleComponent,
    AddScheduleComponent,
    TicketDetailsComponent,
    RegistrationComponent
   ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
