
    export interface Schedule {
        id: number;
        flightNumber: string;
        scheduledDate: string;
        arrival: string;
        departure: string;
        price:number;
    }
