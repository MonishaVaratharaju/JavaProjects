import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { ScheduleService } from '../schedule.service';

@Component({
  selector: 'app-add-schedule',
  templateUrl: './add-schedule.component.html',
  styleUrls: ['./add-schedule.component.css']
})

export class AddScheduleComponent implements OnInit {  

      form: FormGroup;
    
      constructor(    public scheduleService: ScheduleService,
        private router: Router) {
       
       }
    
      ngOnInit(): void {
        this.form = new FormGroup({
          flightNumber: new FormControl('', [Validators.required]),
          scheduledDate: new FormControl('', Validators.required),
          arrival: new FormControl('', [Validators.required]),
          departure: new FormControl('', Validators.required),
          price: new FormControl('', Validators.required)

        });
      }
       
      get f(){
        return this.form.controls;
      }
        
      submit(){
        console.log(this.form.value);
        this.scheduleService.create(this.form.value).subscribe(res => {
             console.log('Schedule added successfully!');
             this.router.navigateByUrl('schedule/index-schedule');
        })
      }
    
    }
    
  
