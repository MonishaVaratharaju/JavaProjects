
  import { Component, OnInit } from '@angular/core';
import { Schedule } from '../schedule';
import { ScheduleService } from '../schedule.service';



@Component({
  selector: 'app-index-schedule',
  templateUrl: './index-schedule.component.html',
  styleUrls: ['./index-schedule.component.css']
})
export class IndexScheduleComponent implements OnInit {

  
    schedules: Schedule[] = [];
  
    constructor(public scheduleService: ScheduleService) { }
  
    ngOnInit(): void {
      this.scheduleService.getAll().subscribe((data: Schedule[])=>{
        this.schedules = data;
        console.log(this.schedules);
      })  
    }
    
    blockFlight(id: number){
      this.scheduleService.delete(id).subscribe(res => {
           this.schedules = this.schedules.filter(item => item.id !== id);
           console.log('Schedule deleted successfully!');
      })
    }
  
  }
  
