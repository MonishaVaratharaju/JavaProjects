  import { Component, OnInit } from '@angular/core';
  import { ActivatedRoute, Router } from '@angular/router';
  import { FormGroup, FormControl, Validators} from '@angular/forms';
import { ScheduleService } from '../schedule.service';
import { Schedule } from '../schedule';
     
  @Component({
    selector: 'app-update-schedule',
    templateUrl: './update-schedule.component.html',
    styleUrls: ['./update-schedule.component.css']
  })
  export class UpdateScheduleComponent implements OnInit {
      
    id: number;
    schedule: Schedule;
    form: FormGroup;
    
    constructor(
      public scheduleService: ScheduleService,
      private route: ActivatedRoute,
      private router: Router
    ) { }
    
    ngOnInit(): void {
      this.id = this.route.snapshot.params['postId'];
      this.scheduleService.find(this.id).subscribe((data: Schedule)=>{
        this.schedule = data;
      });
      
      this.form = new FormGroup({
        flightNumber: new FormControl('', [Validators.required]),
        scheduledDate: new FormControl('', Validators.required),
        arrival: new FormControl('', [Validators.required]),
        departure: new FormControl('', Validators.required),
        price: new FormControl('', Validators.required)
        
      });
    }
     
    get f(){
      return this.form.controls;
    }
       
    submit(){
      console.log(this.form.value);
      this.scheduleService.update(this.id, this.form.value).subscribe(res => {
           console.log('Schedule updated successfully!');
           this.router.navigateByUrl('schedule/index-schedule');
      })
    }
     
  }
