import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
   
import {  Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from './user';


  

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private apiURL = "http://localhost:3000";
   
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  

  constructor(private httpClient: HttpClient) { }

  getAll(): Observable<User[]> {
    return this.httpClient.get<User[]>(this.apiURL + '/registration/')
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  create(post: any): Observable<User> {
    return this.httpClient.post<User>(this.apiURL + '/registration/', JSON.stringify(post), this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }  
   
  find(id: string | number): Observable<User> {
    return this.httpClient.get<User>(this.apiURL + '/registration/' + id)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  update(id: string | number, post: any): Observable<User> {
    return this.httpClient.put<User>(this.apiURL + '/registration/' + id, JSON.stringify(post), this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  delete(id: string | number){
    return this.httpClient.delete<User>(this.apiURL + '/registration/' + id, this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }
    
  
  errorHandler(error: { error: { message: string; }; status: any; message: any; }) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
 }
}
