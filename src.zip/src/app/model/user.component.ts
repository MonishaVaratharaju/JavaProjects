export class User {
  userId:number;
  userName:string;
  userPassword:string;
  userEmail:string;
  roles:string;
  
  constructor(userId : number, userName : string, userPassword : string,userEmail : string,  roles : string){
    this.userId = userId;
    this.userName = userName;
    this.userPassword = userPassword;
    this.userEmail = userEmail;
  
    this.roles = roles;
} 
}
