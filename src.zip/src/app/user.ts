export interface User {
    name : string; 
    contactNumber : number;
    emailid : string;
    password : string;
}
