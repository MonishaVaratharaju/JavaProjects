import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../model/user.component';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor( private router: Router,
    private http: HttpClient) { }


  authenticate(username:string, password:string) {
    if(username == "demo" && password == "demo123"){
      sessionStorage.setItem('username', username);
      sessionStorage.setItem('roles',"CUSTOMER");
      return true;
    }
    else if(username == "admin" && password == "admin"){
      sessionStorage.setItem('username', username);
      sessionStorage.setItem('roles',"ADMIN");
      return true;
    }
    return false;
  }


  signUp(user: User) {
    return user;
  }


}
