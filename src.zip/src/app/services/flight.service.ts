import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FlightService {
  private Url = 'http://localhost:3000/schedules';

  constructor(private http: HttpClient) { }

  searchFlight(from: string,to: string): Observable<Object> {
    return this.http.get(`${this.Url}`);
  }

}
