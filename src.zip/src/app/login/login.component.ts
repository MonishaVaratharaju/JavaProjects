import { Component, OnInit } from '@angular/core';
import { User } from '../model/user.component';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { ThrowStmt } from '@angular/compiler';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

 loginForm: FormGroup;
  user: User={"userId": 0, "userName":"", "userPassword":"", "userEmail":"", "roles":""};
  invalidLogin = false;

  constructor(private router: Router, private formBuilder: FormBuilder,
    private loginservice: AuthenticationService) {
      this.loginForm = formBuilder.group({
        name: ['', Validators.required],
        password: ['', [Validators.required]]
        //, Validators.minLength(6)
      });
     }

  ngOnInit(): void {
  }

  // Check user for authenticatoin
  checkLogin() {
    if (this.loginservice.authenticate(this.loginForm.value.name, this.loginForm.value.password)) {
      this.redirect();
    }
    else {
      console.log("Invalid Credentials");
      this.invalidLogin = true;
    }
    this.loginForm.reset();
  }

  signup() {
    this.router.navigate(["registration"]).then(() => {
      window.location.reload();
    });
  }

  redirect() {
    if (sessionStorage.getItem('roles') === 'CUSTOMER') {
      this.invalidLogin = false;
      this.router.navigate(["home"]).then(() => {
        window.location.reload();
      });
    }
    else if (sessionStorage.getItem('roles') === 'ADMIN') {
      this.invalidLogin = false;
      this.router.navigate(["admin"]).then(() => {
        window.location.reload();
      });
    }
  }

}
